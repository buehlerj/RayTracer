Jeffrey Dean Buehler Jr
CS 410 - 001
(720) 301 - 9261

IMPORTANT: Make sure to use included librarires:
 - Uses external library Jama-1.0.3.jar.

Takes 0, 1, or 2 arguments:

0 : This will run completely internally and does not need any input files (besides the .java files included). This will create masterwork.ppm in the root directory. The image is 1920 x 1080 resolution and has stars of different brighnesses (to simulate depth) randomly generated in the background as pixels.

1 : The argument it takes is any scene file that specifies a camera, lights, and spheres/polygonal models. It will output to masterwork.ppm (overriding any original masterwork.ppm file).

2 : The first argument is a scene file that specifies a camera, lights, and spheres/polygonal models. The second argument is the output file that you specify.

