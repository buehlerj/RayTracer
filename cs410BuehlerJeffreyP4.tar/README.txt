Jeffrey Dean Buehler
CS 410
jeffreydeanbuehler@gmail.com
(720) 301 - 9261


IMPORTANT: Make sure to use included librarires:
 - Uses external library Jama-1.0.3.jar.

Takes two arguments to run: <scene text file> <output file.ppm>

The main method is located in the CS410BuehlerJeff.java file.

